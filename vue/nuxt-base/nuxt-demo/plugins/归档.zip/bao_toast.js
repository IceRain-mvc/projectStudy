import Vue from "vue";

import BaoToast from "./bao"

Vue.use(BaoToast,{a:11});

console.log("111")
