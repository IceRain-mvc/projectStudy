module.exports = {
  testURL: "http://localhost"
};
